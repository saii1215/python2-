# Create sets
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

# Access elements (using loop)
print("Set1 elements:")
for item in set1:
    print(item)

# Union
print("Union:", set1.union(set2))

# Intersection
print("Intersection:", set1.intersection(set2))

# Difference
print("Difference (set1 - set2):", set1.difference(set2))
print("Difference (set2 - set1):", set2.difference(set1))